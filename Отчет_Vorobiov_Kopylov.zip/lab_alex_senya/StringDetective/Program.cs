﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main()
    {
        Console.WriteLine("=== СТРОКОВЫЙ АНАЛИЗАТОР ===");
        Console.Write("Введите текст: ");
        string input = Console.ReadLine();

        while (true)
        {
            Console.WriteLine("\nВыберите действие:");
            Console.WriteLine("1 - Количество слов");
            Console.WriteLine("2 - Самое частое слово");
            Console.WriteLine("3 - Текст без пунктуации");
            Console.WriteLine("4 - Всё вместе");
            Console.WriteLine("5 - Топ слов без стоп-слов (Бонус)");
            Console.WriteLine("0 - Выход");
            Console.Write("\nВаш выбор: ");

            string choice = Console.ReadLine();

            if (choice == "0")
            {
                break;
            }

            switch (choice)
            {
                case "1":
                    Console.WriteLine($"Количество слов: {GetWordCount(input)}");
                    break;

                case "2":
                    Console.WriteLine($"Самое частое слово: \"{GetMostFrequentWord(input)}\"");
                    break;

                case "3":
                    Console.WriteLine($"Текст без пунктуации: {RemovePunctuation(input)}");
                    break;

                case "4":
                    Console.WriteLine("\nРезультаты анализа:");
                    Console.WriteLine($"- Количество слов: {GetWordCount(input)}");
                    Console.WriteLine($"- Самое частое слово: \"{GetMostFrequentWord(input)}\"");
                    Console.WriteLine($"- Текст без пунктуации: {RemovePunctuation(input)}");
                    break;

                case "5":
                    string[] stopWords = { "в", "и", "на", "с", "по", "к", "о", "а", "но", "кот", "собака" };
                    var top = GetTopWords(input, stopWords, 3);
                    Console.WriteLine("\nТоп слов (исключая стоп-слова):");
                    foreach (var pair in top)
                    {
                        Console.WriteLine($"- \"{pair.Key}\": {pair.Value}");
                    }
                    break;

                default:
                    Console.WriteLine("Некорректный ввод. Выберите пункт от 0 до 5.");
                    break;
            }
        }
    }

    static int GetWordCount(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return 0;
        }

        char[] separators = { ' ', '\t', '\n', '\r', ',', '.', '!', '?', ';', ':', '-', '—' };
        string[] words = text.Split(separators, StringSplitOptions.RemoveEmptyEntries);
        return words.Length;
    }

    static string GetMostFrequentWord(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return "";
        }

        char[] separators = { ' ', '\t', '\n', '\r', ',', '.', '!', '?', ';', ':', '-', '—' };
        string[] words = text.ToLower().Split(separators, StringSplitOptions.RemoveEmptyEntries);

        if (words.Length == 0)
        {
            return "";
        }

        Dictionary<string, int> frequency = new Dictionary<string, int>();

        for (int i = 0; i < words.Length; i++)
        {
            string word = words[i];
            if (frequency.ContainsKey(word))
            {
                frequency[word]++;
            }
            else
            {
                frequency[word] = 1;
            }
        }

        string mostFrequent = "";
        int maxCount = 0;

        foreach (KeyValuePair<string, int> pair in frequency)
        {
            if (pair.Value > maxCount)
            {
                maxCount = pair.Value;
                mostFrequent = pair.Key;
            }
        }

        return mostFrequent;
    }

    static string RemovePunctuation(string text)
    {
        if (text == null)
        {
            return null;
        }

        StringBuilder cleanText = new StringBuilder();

        for (int i = 0; i < text.Length; i++)
        {
            if (!char.IsPunctuation(text[i]))
            {
                cleanText.Append(text[i]);
            }
        }

        return cleanText.ToString();
    }

    /// <summary>
    /// Возвращает топ-N самых частотных слов, исключая стоп-слова
    /// </summary>
    /// <param name="text">Входной текст</param>
    /// <param name="stopWords">Список слов для исключения</param>
    /// <param name="topCount">Количество слов для возврата</param>
    /// <returns>Словарь слово -> количество</returns>
    static Dictionary<string, int> GetTopWords(string text, string[] stopWords, int topCount = 5)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return new Dictionary<string, int>();
        }

        // Храним стоп-слова в HashSet без учёта регистра для быстрого поиска за O(1)
        HashSet<string> stopWordsSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (stopWords != null)
        {
            foreach (string word in stopWords)
            {
                stopWordsSet.Add(word);
            }
        }

        char[] separators = { ' ', '\t', '\n', '\r', ',', '.', '!', '?', ';', ':', '-', '—' };
        string[] words = text.ToLower().Split(separators, StringSplitOptions.RemoveEmptyEntries);

        Dictionary<string, int> frequency = new Dictionary<string, int>();

        foreach (string word in words)
        {
            if (!stopWordsSet.Contains(word))
            {
                if (frequency.ContainsKey(word))
                {
                    frequency[word]++;
                }
                else
                {
                    frequency[word] = 1;
                }
            }
        }

        // Сортируем по убыванию частоты и берём topCount элементов
        return frequency.OrderByDescending(x => x.Value)
                        .Take(topCount)
                        .ToDictionary(x => x.Key, x => x.Value);
    }
}